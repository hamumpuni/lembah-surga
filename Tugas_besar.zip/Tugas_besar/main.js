// menu open close
let menu = document.querySelector(".menu-icon");

menu.onclik = () => {
  menu.classList.toggle("move");
};
<button onclick="document.getElementById('booking-form').scrollIntoView({ behavior: 'smooth' });">
  Book Now
</button>